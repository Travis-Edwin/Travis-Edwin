#include <iostream>

using namespace std;

int main()
{
    // Declare variables for investment amount, annual interest rate, and number of years
    double investmentAmount;
    double annualInterestRate;
    int numberOfYears;

    // Prompt user for investment amount
    cout << "Enter investment amount: ";
    cin >> investmentAmount;

    // Prompt user for annual interest rate
    cout << "Enter annual interest rate: ";
    cin >> annualInterestRate;

    // Prompt user for number of years
    cout << "Enter number of years: ";
    cin >> numberOfYears;

    // Convert annual interest rate to monthly (as a decimal)
    double monthlyInterestRate = annualInterestRate / 1200;

    // Calculate accumulated (future) value using given formula
    double accumulatedValue = investmentAmount * pow(1 + monthlyInterestRate, numberOfYears * 12);

    // Output the accumulated value, formatted to 2 decimal places
    //cout << fixed << setprecision(2);
    cout << "Accumulated value is " << accumulatedValue << endl;

    return 0; // Indicate successful execution
}